#ifndef ISODD_H
#define ISODD_H
int isOdd(int num);

#endif
